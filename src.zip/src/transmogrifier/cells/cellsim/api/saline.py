# cellsim/api/saline_api.py
from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Iterable, List, Sequence, Optional
from sympy import lambdify, symbols, Integer, Float
from ..engine.saline import SalineEngine
from ..data.state import Cell, Bath, Organelle
from ..core.geometry import sphere_area_from_volume

@dataclass
class IntegerAllocatorCfg:
    method: str = "adams"          # "truncate" | "adams"
    protect_under_one: bool = True
    bump_under_one: bool = True

class SalinePressureAPI:
    """
    Back-compat facade:
      - Keeps your s/p-expression bar view + integer allocator.
      - Builds cellsim Cell/Bath and runs SalineEngine for physics.
      - Optional hooks to BitBitBuffer for expand/snap.
    """
    def __init__(self,
                 cells: List[Cell],
                 bath: Bath,
                 *,
                 species: Iterable[str] = ("Na","K","Cl","Imp"),
                 epsilon: float = 1e-6,
                 int_alloc: IntegerAllocatorCfg = IntegerAllocatorCfg(),
                 chars: Optional[List[str]] = None,
                 width: int = 80,
                 s_exprs: Optional[Sequence] = None,
                 p_exprs: Optional[Sequence] = None):
        self.cells = cells
        self.bath = bath
        self.species = tuple(species)
        self.epsilon = float(epsilon)
        self.int_alloc = int_alloc
        self.chars = chars or [chr(97+i) for i in range(len(cells))]
        self.width = int(width)

        # optional bar-driver (legacy “view”)
        self.t = symbols('t')
        self.s_exprs = list(s_exprs) if s_exprs is not None else [Integer(c.n.get("Imp", 0.0)) for c in cells]
        self.p_exprs = list(p_exprs) if p_exprs is not None else [Float(getattr(c, "base_pressure", 0.0)) for c in cells]
        self.s_funcs = [lambdify(self.t, e, 'math') for e in self.s_exprs]
        self.p_funcs = [lambdify(self.t, e, 'math') for e in self.p_exprs]

        # init engine
        for c in self.cells:
            if c.A0 <= 0.0:
                A0, _ = sphere_area_from_volume(c.V); c.A0 = A0
        self.engine = SalineEngine(self.cells, self.bath, species=self.species)

    # ---- legacy “view”: equilibrium fractions & bar ----
    def equilibrium_fracs(self, t: float) -> List[float]:
        s_vals = [f(t) for f in self.s_funcs]
        p_vals = [f(t) for f in self.p_funcs]
        r = []
        eps = self.epsilon
        for si, pi in zip(s_vals, p_vals):
            denom = pi if abs(pi) > eps else eps
            r.append(si/denom)
        s = sum(r); 
        if abs(s) < eps:
            return [1.0/len(r)]*len(r)
        return [ri/s for ri in r]

    def equilibrium_bar(self, t: float) -> str:
        fracs = self.equilibrium_fracs(t)
        if self.int_alloc.method == "truncate":
            segs = self._integer_allocate_truncate(fracs, self.width)
        else:
            segs = self._integer_allocate_adams(fracs, self.width)
        return '|' + ''.join(self.chars[i]*segs[i] for i in range(len(segs))) + '|'

    def _integer_allocate_truncate(self, fracs, W):
        from math import floor, ceil
        quotas = [f*W for f in fracs]
        ceilings = [ceil(q) for q in quotas]
        K = sum(ceilings) - W
        if K <= 0: return ceilings
        costs = []
        for i, q in enumerate(quotas):
            if q <= 1.0 and self.int_alloc.protect_under_one:
                cost = float('inf')
            else:
                cost = 1 - (q - floor(q))
            costs.append((cost, i))
        for _, idx in sorted(costs, key=lambda x: x[0])[:K]:
            ceilings[idx] -= 1
        return ceilings

    def _integer_allocate_adams(self, fracs, W):
        from math import floor, ceil
        quotas = [f*W for f in fracs]
        ceilings = [max(1, ceil(q)) if self.int_alloc.bump_under_one else ceil(q) for q in quotas]
        K = sum(ceilings) - W
        if K <= 0: return ceilings
        costs = []
        for i, q in enumerate(quotas):
            if q < 1.0 and self.int_alloc.protect_under_one:
                cost = float('inf')
            else:
                cost = 1 - (q - floor(q))
            costs.append((cost, i))
        for _, idx in sorted(costs, key=lambda x: x[0])[:K]:
            ceilings[idx] -= 1
        return ceilings

    # ---- physics step (cellsim backend) ----
    def step(self, dt: float) -> float:
        """Returns suggested next dt (adaptive)."""
        return self.engine.step(dt)

    # ---- helpers to construct from your legacy sim object ----
    @classmethod
    def from_legacy(cls, sim) -> "SalinePressureAPI":
        # Map legacy cells → Cell; salinity → Imp; pressure → base_pressure
        cells = []
        for legacy in sim.cells:
            V = float(legacy.right - legacy.left)
            cell = Cell(V=V,
                        n={"Imp": float(getattr(legacy, "salinity", 0.0)),
                           "Na": 0.0, "K": 0.0, "Cl": 0.0},
                        base_pressure=float(getattr(legacy, "pressure", 0.0)),
                        elastic_k=float(getattr(legacy, "elastic_k", 0.1)),
                        visc_eta=float(getattr(legacy, "visc_eta", 0.0)))
            # organelles if present
            if hasattr(legacy, "organelles"):
                for o in legacy.organelles:
                    cell.organelles.append(
                        Organelle(volume_total=float(o.volume_total),
                                  lumen_fraction=float(getattr(o, "lumen_fraction", 0.7)),
                                  n=dict(getattr(o, "solute", {})))
                    )
            A0, _ = sphere_area_from_volume(cell.V); cell.A0 = A0
            cells.append(cell)

        bath = Bath(V=sum(c.V for c in cells),
                    n={"Na": float(getattr(sim, "external_concentration", 1500.0)),
                       "K": 0.0, "Cl": float(getattr(sim, "external_concentration", 1500.0)), "Imp": 0.0},
                    pressure=float(getattr(sim, "external_pressure", 1e4)),
                    temperature=float(getattr(sim, "temperature", 298.15)),
                    compressibility=float(getattr(sim, "bath_compressibility", 0.0)))
        return cls(cells, bath,
                   species=("Na","K","Cl","Imp"),
                   epsilon=float(getattr(sim, "epsilon", 1e-6)),
                   chars=[chr(97+i) for i in range(len(cells))],
                   width=int(getattr(sim, "bitbuffer", getattr(sim, "width", 80)).mask_size if hasattr(sim, "bitbuffer") else int(getattr(sim,"width",80))),
                   s_exprs=getattr(sim, "s_exprs", None),
                   p_exprs=getattr(sim, "p_exprs", None))
