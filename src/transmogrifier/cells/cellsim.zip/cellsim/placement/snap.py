def snap_cell_walls(cells, proposals):
    return proposals
