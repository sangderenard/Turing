def expand(events, cells, proposals):
    return proposals
