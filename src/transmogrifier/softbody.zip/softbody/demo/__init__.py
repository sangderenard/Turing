"""Demonstration scripts showcasing the softbody engine."""

__all__ = [
    "run_ascii_demo",
    "run_numpy_demo",
    "run_opengl_demo",
]
