"""Softbody simulation components (XPBD-based)."""

__all__ = ["bridge", "demo", "engine"]
