
# softbody_xpbd_mvp2

*XPBD-authentic* scaffold: stretch, volume, dihedral bending, and plane contacts via XPBD.
ASCII demo renders a thin Z slab as a colored grid.

Run:
  python -m demo.run_ascii_demo
